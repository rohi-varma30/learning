import React, { useEffect, useState } from 'react';
import '../statedata.css'
const Statedata = () => {
  const [data,setData]=useState([]);
  const [search, setSearch] = useState("");
  const today = new Date();
  const getCovidData = async () => {
    const res = await fetch('https://api.rootnet.in/covid19-in/stats/latest');
    const resultData = await res.json()
    console.log(resultData.data.regional);
    setData(resultData.data.regional);
  }

  useEffect(() => {
      getCovidData();
  }, []);


  return (
    <>
      <div className='container-fluid mt-5'>
        <div className='main-heading'>
          <center></center><h1 className='mb-5 text-center'> <span className="fw-bold font-monospace">COVID-19 CASES </span>IN INDIA</h1><center/>
        </div>
        <div>
        <input
          type="text"
          placeholder="Search State"
          className="bg-gray-200 text-slate-900 rounded-md p-2 my-10 mx-1"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>
      <div className='table-responsive'>
        <table className='table table-hover'>
          <thead className='table-dark'>
            <tr>
              <th>STATE</th>
              <th>CONFIRMED (INDIAN)</th>
              <th>CONFIRMED (FOREIGN)</th>
              <th>DISCHARGED</th>
              <th>DEATHS</th>
              <th>TOTAL CASES</th>
            </tr>
          </thead>
          <tbody>
          {
            data.map((currentElement,index)=>{
              return(
                <tr key={index}>
              <th>{currentElement.loc}</th>
              <td>{currentElement.confirmedCasesIndian}</td>
              <td>{currentElement.confirmedCasesForeign}</td>
              <td>{currentElement.discharged}</td>
              <td>{currentElement.deaths}</td>
              <td>{currentElement.totalConfirmed}</td>
            </tr>     
            )
            })
          }
          </tbody>
          <footer>
        <p>Copyright &copy; {today.getFullYear()}</p>
        <center>Developed by @ROHITH VARMA</center>
      </footer>
        </table>
      </div>

      </div>
    </>
  )
}

export default Statedata