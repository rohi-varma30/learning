import "./App.css";
import Statedata from './Statedata/statedata';
function App() {
  return(
    <div className="App">
      <Statedata/>
    </div>
  );
}
export default App;
